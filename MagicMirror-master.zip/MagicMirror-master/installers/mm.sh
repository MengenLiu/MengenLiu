cd ~/MagicMirror
DISPLAY=:0 npm start
